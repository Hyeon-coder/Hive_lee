/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   input_parse.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: JuHyeon <juhyeonl@student.hive.fi>         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/28 04:06:33 by JuHyeon           #+#    #+#             */
/*   Updated: 2025/02/28 04:34:32 by JuHyeon          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../push_swap.h"

int	check_double(t_stack *a)
{
	t_stack	*current;
	t_stack	*compare;

	current = a;
	while (current)
	{
		compare = current->next;
		while (compare)
		{
			if (current->num == compare->num)
				return (1);
			compare = compare->next;
		}
		current = current->next;
	}
	return (0);
}

t_stack	*input_tmp_stack(char **args, int size)
{
	t_stack	*stack;
	t_stack	*new_node;
	int		i;

	stack = NULL;
	i = 0;
	while (i < size)
	{
		new_node = ft_stack_lstnew(ft_atoi(args[i]));
		if (!new_node)
		{
			ft_stack_lstclear(&stack);
			return (NULL);
		}
		stack_append(&stack, new_node);
		i++;
	}
	return (stack);
}

static char	**parse_args(int ac, char **av)
{
	char	**args;

	args = NULL;
	if (ac == 2 && av[1])
	{
		args = ft_split(av[1], ' ');
	}
	else if (ac > 2)
	{
		args = av + 1;
	}
	return (args);
}

t_stack	*input_parse(int ac, char **av)
{
	t_stack	*stack;
	char	**args;
	int		i;

	args = parse_args(ac, av);
	stack = input_tmp_stack(args, ac);
	if (!stack && ac == 2 && args)
	{
		i = 0;
		while (args[i])
			free(args[i++]);
		free(args);
	}
	return (stack);
}
